/**
 * CCDN v1.4.18
 */

$(document).ready(function () {
    $('.ccdn-lite-update-embed-js').on('click', function () {
        let that = $(this);
        let url = that.data('update-url');

        /**
         * Search Fields
         */
        let kinopoiskIdField = $('#xf_' + configCCDNLite.kinopoisk_id_field);
        let imdbIdField = $('#xf_' + configCCDNLite.imdb_id_field);
        let worldArtIdField = $('#xf_' + configCCDNLite.world_art_id_field);

        let imdbId = '';
        if (imdbIdField.val() !== undefined) {
            imdbId = imdbIdField.val().replace('tt', '')
        }

        that.html(btnConditionTextCCDNLite.search);
        $.post(url, {
            kinopoisk_id: kinopoiskIdField.val(),
            imdb_id: imdbId,
            world_art_id: worldArtIdField.val(),
        }).done(function (response) {
            let title = $('#title');

            if (title.val().length === 0) {
                title.val(response.name);
            }

            if (response.set_short_desc) {
                let shortStory = $('#short_story');
                if (shortStory.froalaEditor !== undefined) {
                    shortStory.froalaEditor('html.set', response.description);
                } else {
                    shortStory.text(response.description);
                }

            }

            if (response.set_description) {
                let fullStory = $('#full_story');
                if (fullStory.froalaEditor !== undefined) {
                    fullStory.froalaEditor('html.set', response.description);
                } else {
                    fullStory.text(response.description);
                }
            }

            setData(configCCDNLite, 'embed_field', response.iframe_url);
            setData(configCCDNLite, 'kinopoisk_id_field', response.kinopoisk_id);
            setData(configCCDNLite, 'imdb_id_field', response.imdb_id);
            setData(configCCDNLite, 'world_art_id_field', response.world_art_id);
            setData(configCCDNLite, 'ccdn_id_field', response.id);

            setData(configCCDNLite, 'video_quality_field', response.quality);
            setData(configCCDNLite, 'button_origin_name', response.name_eng);
            setData(configCCDNLite, 'video_voice_field', response.voiceActing);
            setData(configCCDNLite, 'video_first_voice_field', response.firstVoice);
            setData(configCCDNLite, 'button_country', response.country);
            setData(configCCDNLite, 'button_actors', response.actors);
            setData(configCCDNLite, 'button_director', response.director);
            setData(configCCDNLite, 'button_year', response.year);
            setData(configCCDNLite, 'button_rating_imdb', response.imdb);
            setData(configCCDNLite, 'button_rating_kinopoisk', response.kinopoisk);
            setData(configCCDNLite, 'button_rating_world_art', response.world_art);
            setData(configCCDNLite, 'button_poster', response.poster);
            setData(configCCDNLite, 'button_age', response.age);
            setData(configCCDNLite, 'button_genres', response.genre);
            setData(configCCDNLite, 'button_time', response.time);
            setData(configCCDNLite, 'button_premier', response.premier);
            setData(configCCDNLite, 'button_premier_rus', response.premier_rus);
            setData(configCCDNLite, 'button_trailer', response.trailer);
            setData(configCCDNLite, 'episode_count_field', response.episode_count);
            setData(configCCDNLite, 'serial_season_field', response.season);
            setData(configCCDNLite, 'serial_episode_field', response.episode);
            setData(configCCDNLite, 'collaps_franchise_ads_status_field', response.ads);

            setData(configCCDNLite, 'button_slogan', response.slogan);
            setData(configCCDNLite, 'button_screenwriter', response.screenwriter);
            setData(configCCDNLite, 'button_producer', response.producer);
            setData(configCCDNLite, 'button_operator', response.operator);
            setData(configCCDNLite, 'button_design', response.design);
            setData(configCCDNLite, 'button_editor', response.editor);
            setData(configCCDNLite, 'button_actors_dubbing', response.actors_dubl);
            setData(configCCDNLite, 'button_budget', response.budget);
            setData(configCCDNLite, 'button_fees_use', response.fees_use);
            setData(configCCDNLite, 'button_fees_world', response.fees_world);
            setData(configCCDNLite, 'button_fees_rus', response.fees_rus);
            setData(configCCDNLite, 'button_rate_mpaa', response.rate_mpaa);
            setData(configCCDNLite, 'button_trivia', response.trivia);
            setData(configCCDNLite, 'button_composer', response.composer);

            uploadField(configCCDNLite, 'button_download_poster', response.poster);

        }).fail(function (response) {
            DLEalert('Что-то пошло не так. Код ошибки: ' + response.status + '<br> Сообщение: ' + response.responseText, "Сообщение об ошибке!");
        }).always(function () {
            that.html(btnConditionTextCCDNLite.normal);
        }).then(function () {
        });
    });
});

/**
 *
 * @param {object} config
 * @param {string} field
 * @param  data
 * @returns {boolean}
 */
function setData(config, field, data) {

    if (data === null || data === undefined) {
        return false;
    }

    if (field in config && config[field] !== null) {
        let customField = document.getElementsByName('xfield[' + config[field] + ']')[0];

        if (typeof customField === 'undefined') {
            return false;
        }

        customField.value = data;
        $(customField).trigger('change');

        if (customField.classList.contains('switch') && customField.checked !== data) {
            $(customField).trigger('click');
        }

        return true;
    }

    return false;
}

/**
 *
 * @param config
 * @param field
 * @param fileUrl
 * @return {boolean}
 */
function uploadField(config, field, fileUrl) {

    if (!(field in config) && config[field] === null) {
        return false;
    }
    let customField = document.getElementById('xfupload_' + config[field]);

    if (typeof customField === 'undefined') {
        return false;
    }

    let query = $.param({
        mod: 'upload',
        subaction: 'upload',
        news_id: newsIdCCDNLite,
        area: 'xfieldsimage',
        author: memberCCDNLite.name,
        user_hash: loginHashIdCCDNLite,
        xfname: config[field],
    });


    let dle_v = parseInt(CCDNLiteDLEConfig.version_id);
    let url = '/engine/ajax/controller.php?';

    if (dle_v <= 12) {
        url = 'engine/ajax/upload.php?'
    }

    $.post(url + query, {
        imageurl: fileUrl,
    }).done(function (response) {
        response = JSON.parse(response);
        if (response.success) {
            var returnbox = response.returnbox;
            var returnval = response.xfvalue;
            returnbox = returnbox.replace(/&lt;/g, "<");
            returnbox = returnbox.replace(/&gt;/g, ">");
            returnbox = returnbox.replace(/&amp;/g, "&");
            $('#uploadedfile_' + config[field]).html(returnbox);
            $('#xf_' + config[field]).val(returnval);
            $('#xfupload_' + config[field] + ' .qq-upload-button, #xfupload_' + config[field] + ' .qq-upload-button input').attr("disabled", "disabled");

            setData(config, 'button_download_poster_url', '/uploads/posts/' + returnval);

            setTimeout(function () {
                $('#uploadfile-' + config[field]).fadeOut('slow', function () {
                    $(this).remove();
                });
            }, 1000);

        } else {
            if (response.error) $('#uploadfile-' + config[field] + ' .qq-status').append('<br /><span style="color:red;">' + response.error + '</span>');
            setTimeout(function () {
                $('#uploadfile-' + config[field]).fadeOut('slow');
            }, 4000);
        }
    }).fail(function (response) {
        console.log(response);
    }).then(function (response) {
    });
}
