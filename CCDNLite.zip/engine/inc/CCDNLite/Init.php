<?php

namespace CCDNLite;

use CCDNLite\Controllers\BtnController;
use CCDNLite\Controllers\DeletePluginController;
use CCDNLite\Controllers\LogsController;
use CCDNLite\Controllers\MainController;
use CCDNLite\Controllers\ModuleController;
use CCDNLite\Controllers\SettingsController;
use CCDNLite\Controllers\UpdatePostController;
use CCDNLite\Helpers\Exception\CCDNException;
use CCDNLite\Helpers\Http\Router;
use CCDNLite\Helpers\Http\Url;

class Init extends Router
{

    /**
     * @throws CCDNException
     */
    public function run()
    {
        /**
         * MainController
         */
        $this->get('main', MainController::class, 'main');
        $this->get('main-clear-cache', MainController::class, 'clearCache');
        $this->get('main-update-plugin', MainController::class, 'update');
        /**
         * BtnController
         */
        $this->get('btn-settings', BtnController::class, 'main');
        $this->post('btn-save-config', BtnController::class, 'saveSettings');
        $this->post('btn-get-franchise-details', BtnController::class, 'getFranchiseDetails');
        $this->get('btn-search', BtnController::class, 'search');
        /**
         * UpdatePostController
         */
        $this->get('update-post', UpdatePostController::class, 'updateFilms');
        $this->get('update-post-get-chunk-count', UpdatePostController::class, 'chunksCount');
        /**
         * SettingsController
         */
        $this->get('settings', SettingsController::class, 'settings');
        $this->post('settings-save-config', SettingsController::class, 'saveConfig');
        /**
         * ModuleController
         */
        $this->get('module', ModuleController::class, 'main');
        $this->post('module-save-settings', ModuleController::class, 'saveSettings');
        /**
         * LogsController
         */
        $this->get('logs', LogsController::class, 'main');
        $this->get('logs-print', LogsController::class, 'printLog');
        $this->get('logs-download', LogsController::class, 'download');
        $this->get('logs-delete', LogsController::class, 'delete');
        $this->get('logs-delete-all', LogsController::class, 'deleteAll');
        /**
         * DeletePluginController
         */
        $this->get('delete-plugin', DeletePluginController::class, 'delete');


        return $this->touch(Url::staticGetAction());
    }

}
