<?php

namespace CCDNLite\Controllers;

use CCDNLite\Helpers\Api\ApiHandler;
use CCDNLite\Helpers\Controller;
use CCDNLite\Helpers\DB\SettingsSave;
use CCDNLite\Helpers\Exception\CCDNException;
use CCDNLite\Helpers\Http\Request;
use CCDNLite\Helpers\Http\Response;
use CCDNLite\Helpers\Http\Url;
use CCDNLite\Helpers\Settings;
use CCDNLite\Helpers\XFields;

class SettingsController extends Controller
{

    protected $viewsFolder = 'settings';

    /**
     * @return string
     */
    public function settings()
    {
        $api = new ApiHandler();

        $voices = $api->getVoices([
            'limit' => 500
        ]);

        $config = Settings::staticAll();

        $videoVoicePriority = $config->getJsonDecode('video_voice_priority');
        $videoVoicesDisable = $config->getJsonDecode('video_voices_disabled');
        return Response::staticMake($this->render('settings', [
            'config' => $config,
            'customFields' => XFields::staticLoad(),
            'voices' => $voices,
            'videoVoicePriority' => $videoVoicePriority,
            'videoVoicesDisable' => $videoVoicesDisable,
        ]));
    }

    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {

        $settings = $request->post('settings');

        $voicePriorityJson = '';
        $voicesDisabledJson = '';

        if (isset($settings['video_voice_priority'])) {
            $voicePriorityJson = json_encode($settings['video_voice_priority'], JSON_UNESCAPED_UNICODE);
        }

        if (isset($settings['video_voices_disabled'])) {
            $voicesDisabledJson = json_encode($settings['video_voices_disabled'], JSON_UNESCAPED_UNICODE);
        }

        $settings['video_voice_priority'] = $voicePriorityJson;
        $settings['video_voices_disabled'] = $voicesDisabledJson;
        $configSave = new SettingsSave($settings);
        $configSave->main();

        Response::staticRedirect(Url::staticTo('settings'));
    }
}
