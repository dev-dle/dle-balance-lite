<?php


namespace CCDNLite\Helpers;


class CCDNBenchMark
{
    private static $time;
    private static $memoryUse;
    private static $memoryPeakUse;

    public static function start()
    {
        self::$time = microtime(true);
        self::$memoryUse = memory_get_usage();
        self::$memoryPeakUse = memory_get_peak_usage();
    }


    public static function end()
    {
        $time_end = microtime(true);
        $memoryUse = memory_get_usage();
        $memoryPeakUse = memory_get_peak_usage();
        return [
            'Time' => $time_end - self::$time,
            'Memory' => [
                'ccdn' => [
                    'use' => self::convertMemory($memoryUse - self::$memoryUse),
                    'peak_use' => self::convertMemory($memoryPeakUse - self::$memoryPeakUse),
                ],
                'total' => [
                    'use' => self::convertMemory($memoryUse),
                    'peak_use' => self::convertMemory($memoryPeakUse),
                ],
            ],
        ];
    }

    public static function endDD()
    {
        echo '<pre>';
        print_r(self::end());
        echo '</pre>';
        die();
    }

    private static function convertMemory($size)
    {
        $unit = ['b', 'kb', 'mb', 'gb', 'tb', 'pb'];
        return @round($size / (1024 ** ($i = floor(log($size, 1024)))), 2).' '.$unit[$i];
    }

}
