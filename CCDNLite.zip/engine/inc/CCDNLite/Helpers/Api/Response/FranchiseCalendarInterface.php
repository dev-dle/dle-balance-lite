<?php

namespace CCDNLite\Helpers\Api\Response;


use CCDNLite\Helpers\Api\Response\Field\IframeUrlFieldInterface;
use CCDNLite\Helpers\Api\Response\Field\TypeFieldInterface;
use CCDNLite\Helpers\Api\Response\Field\VoicesFieldInterface;

interface FranchiseCalendarInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return TypeFieldInterface
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return string|null
     */
    public function getQuality();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return VoicesFieldInterface
     */
    public function getVoiceActing();

    /**
     * @return int|null;
     */
    public function getSeasonNumber();

    /**
     * @return int|null;
     */
    public function getEpisodeNumber();
}
