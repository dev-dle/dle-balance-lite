<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class ActorsField extends ArrayField implements ActorsFieldInterface
{

}
