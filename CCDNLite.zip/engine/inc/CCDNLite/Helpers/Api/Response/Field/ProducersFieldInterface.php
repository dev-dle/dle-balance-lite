<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface ProducersFieldInterface extends ArrayFieldInterface
{

}
