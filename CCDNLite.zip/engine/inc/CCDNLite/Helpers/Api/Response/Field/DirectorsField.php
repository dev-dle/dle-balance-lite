<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class DirectorsField extends ArrayField implements DirectorsFieldInterface
{

}
