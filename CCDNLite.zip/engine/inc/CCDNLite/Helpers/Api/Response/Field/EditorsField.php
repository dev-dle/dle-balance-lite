<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class EditorsField extends ArrayField implements EditorsFieldInterface
{

}
