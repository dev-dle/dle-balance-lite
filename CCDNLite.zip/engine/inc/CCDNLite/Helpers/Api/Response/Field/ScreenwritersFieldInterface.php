<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface ScreenwritersFieldInterface extends ArrayFieldInterface
{

}
