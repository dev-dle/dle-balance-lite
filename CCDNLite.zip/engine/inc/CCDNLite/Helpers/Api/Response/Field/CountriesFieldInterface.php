<?php

namespace CCDNLite\Helpers\Api\Response\Field;

interface CountriesFieldInterface extends ArrayFieldInterface
{

}
