<?php


namespace CCDNLite\Helpers\Api\Response\Field;

interface ArrayFieldInterface
{

    /**
     * @return array
     */
    public function getList();

    /**
     * @param  string  $deliver
     * @return string
     */
    public function implode($deliver = ', ');

    /**
     * @return bool
     */
    public function isEmpty();

    /**
     * @param  mixed  $item
     * @param  bool  $strict
     * @return bool
     */
    public function has($item, $strict = true);
}
