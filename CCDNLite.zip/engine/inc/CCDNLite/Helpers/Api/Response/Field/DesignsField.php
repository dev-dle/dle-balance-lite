<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class DesignsField extends ArrayField implements DesignsFieldInterface
{
}
