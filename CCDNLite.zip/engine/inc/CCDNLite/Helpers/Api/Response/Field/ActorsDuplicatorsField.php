<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class ActorsDuplicatorsField extends ArrayField implements ActorsDuplicatorsFieldInterface
{
}
