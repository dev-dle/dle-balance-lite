<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class ScreenwritersField extends ArrayField implements ScreenwritersFieldInterface
{
}
