<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface EditorsFieldInterface extends ArrayFieldInterface
{

}
