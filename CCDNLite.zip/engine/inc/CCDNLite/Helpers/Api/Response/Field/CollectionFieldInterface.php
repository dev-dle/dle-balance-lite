<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface CollectionFieldInterface extends ArrayFieldInterface
{

}
