<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface ActorsFieldInterface extends ArrayFieldInterface
{

}
