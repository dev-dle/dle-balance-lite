<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class PartsField extends ArrayField implements PartsFieldInterface
{
}
