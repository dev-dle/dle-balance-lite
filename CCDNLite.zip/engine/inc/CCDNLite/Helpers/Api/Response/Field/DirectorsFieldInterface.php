<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface DirectorsFieldInterface extends ArrayFieldInterface
{

}
