<?php

namespace CCDNLite\Helpers\Api\Response\Items;

use CCDNLite\Helpers\Api\Response\Field\IframeUrlFieldInterface;

interface SeasonItemInterface extends ItemInterface
{
    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return EpisodeContainerInterface
     */
    public function getEpisodes();

}
