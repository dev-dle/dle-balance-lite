<?php


namespace CCDNLite\Helpers\Http;

use CCDNLite\Helpers\FacadeStatic;

/**
 * Class RequestManager
 *
 * @method static mixed staticPost($param = '')
 * @method static string|null staticGetUserAgent()
 * @method static string|null staticGetReferer()
 * @method static mixed staticGet($param = '')
 *
 * @package CCDNLite\Helpers
 */
class Request extends FacadeStatic
{

    /**
     * @return Request
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  string  $param
     *
     * @return mixed
     */
    public function post($param = '')
    {
        if (!empty($param)) {
            return isset($_POST[$param]) ? $_POST[$param] : null;
        }

        return $_POST;
    }

    /**
     * @return string|null
     */
    public function getUserAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null;
    }

    /**
     * @return string|null
     */
    public function getReferer()
    {
        return isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : null;
    }

    /**
     * @param  string  $param
     *
     * @return mixed
     */
    public function get($param = '')
    {
        if (!empty($param)) {
            return isset($_GET[$param]) ? $_GET[$param] : null;
        }

        return $_GET;
    }

}
