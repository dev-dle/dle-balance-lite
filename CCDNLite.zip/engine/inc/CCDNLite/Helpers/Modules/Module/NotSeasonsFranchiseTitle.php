<?php

namespace CCDNLite\Helpers\Modules\Module;

use CCDNLite\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDNLite\Helpers\Entities\Config;
use CCDNLite\Helpers\Entities\Post;
use CCDNLite\Helpers\FacadeStatic;

/**
 * Class NotSeasonsFranchiseTitle
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDNLite\Helpers\Modules\Module
 */
class NotSeasonsFranchiseTitle extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return NotSeasonsFranchiseTitle
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title === '1') {
            return $this->_handlerTitle($config, $response, $post);
        }

        return $post->title;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerTitle(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $title = $config->module_title_pattern_not_season;

        if (empty($title)) {
            return $post->title;
        }

        $title = $segments->replaceEpisode($title, '');
        $title = $segments->replaceSeason($title, '');

        $title = $segments->replaceYear($title, $response->getYear());

        $title = $segments->replaceOriginName($title, $response->getNameEng());

        $title = $segments->replaceTitle($title, $response->getName());

        return $title;
    }
}
