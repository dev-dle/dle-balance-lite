<?php
/**
 * CCDN-Lite button (edit|add) news v1.0
 */

use CCDNLite\Controllers\BtnController;
use CCDNLite\Helpers\Logger\Log;
use CCDNLite\Helpers\Logger\LogType;

require_once ENGINE_DIR.'/inc/CCDNLite/vendor/autoload.php';


try {
    $controller = new BtnController();
    return $controller->renderButton();
} catch (Exception $e) {
    $log = new Log();
    $enter = PHP_EOL;
    $error = "Message: {$e->getMessage()}{$enter}File: {$e->getFile()} Line: {$e->getLine()}{$enter}Trace: {$e->getTraceAsString()}";
    $log->write(LogType::ACTION_BUTTON, $error);
    ob_start();
    ?>
    <p><b>CCDNLite Message:</b> <?php echo $e->getMessage() ?></p>
    <?php
    return ob_get_clean();
}





