$(document).ready(function () {

    let select = $('#ccdn-lite-search');

    select.select2({
        placeholder: 'Найти...',
        width: '100%',
        allowClear: true,
        multiple: false,
        ajax: {
            url: select.data('url'),
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    q: params.term
                };
            },
            cache: true
        },
        minimumInputLength: 2,
        language: {
            inputTooShort: function () {
                return "Пожалуйста, введите 2 или более символов";
            }
        },
        templateResult: formatRepo,
        templateSelection: function (repo) {
            return repo.name;
        }
    });

    select.on('select2:select', function (e) {
        let data = e.params.data;
        select.val(null).trigger('change.select2');
        select.select2('close');

        $.post(select.data('update-url'), {
            kinopoisk_id: data.kinopoisk_id,
        }).done(function (response) {

            $('#title').val(response.name);

            if (response.set_short_desc) {
                let shortStory = $('#short_story');
                if (shortStory.froalaEditor !== undefined) {
                    shortStory.froalaEditor('html.set', response.description);
                } else {
                    shortStory.text(response.description);
                }

            }

            if (response.set_description) {
                let fullStory = $('#full_story');
                if (fullStory.froalaEditor !== undefined) {
                    fullStory.froalaEditor('html.set', response.description);
                } else {
                    fullStory.text(response.description);
                }
            }

            setData(configCCDNLite, 'embed_field', response.iframe_url);
            setData(configCCDNLite, 'kinopoisk_id_field', response.kinopoisk_id);
            setData(configCCDNLite, 'imdb_id_field', response.imdb_id);
            setData(configCCDNLite, 'world_art_id_field', response.world_art_id);
            setData(configCCDNLite, 'ccdn_id_field', response.id);

            setData(configCCDNLite, 'video_quality_field', response.quality);
            setData(configCCDNLite, 'button_origin_name', response.name_eng);
            setData(configCCDNLite, 'video_voice_field', response.voiceActing);
            setData(configCCDNLite, 'video_first_voice_field', response.firstVoice);
            setData(configCCDNLite, 'button_country', response.country);
            setData(configCCDNLite, 'button_actors', response.actors);
            setData(configCCDNLite, 'button_director', response.director);
            setData(configCCDNLite, 'button_year', response.year);
            setData(configCCDNLite, 'button_rating_imdb', response.imdb);
            setData(configCCDNLite, 'button_rating_kinopoisk', response.kinopoisk);
            setData(configCCDNLite, 'button_rating_world_art', response.world_art);
            setData(configCCDNLite, 'button_poster', response.poster);
            setData(configCCDNLite, 'button_age', response.age);
            setData(configCCDNLite, 'button_genres', response.genre);
            setData(configCCDNLite, 'button_time', response.time);
            setData(configCCDNLite, 'button_premier', response.premier);
            setData(configCCDNLite, 'button_premier_rus', response.premier_rus);
            setData(configCCDNLite, 'button_trailer', response.trailer);
            setData(configCCDNLite, 'episode_count_field', response.episode_count);
            setData(configCCDNLite, 'serial_season_field', response.season);
            setData(configCCDNLite, 'serial_episode_field', response.episode);
            setData(configCCDNLite, 'collaps_franchise_ads_status_field', response.ads);

            setData(configCCDNLite, 'button_slogan', response.slogan);
            setData(configCCDNLite, 'button_screenwriter', response.screenwriter);
            setData(configCCDNLite, 'button_producer', response.producer);
            setData(configCCDNLite, 'button_operator', response.operator);
            setData(configCCDNLite, 'button_design', response.design);
            setData(configCCDNLite, 'button_editor', response.editor);
            setData(configCCDNLite, 'button_actors_dubbing', response.actors_dubl);
            setData(configCCDNLite, 'button_budget', response.budget);
            setData(configCCDNLite, 'button_fees_use', response.fees_use);
            setData(configCCDNLite, 'button_fees_world', response.fees_world);
            setData(configCCDNLite, 'button_fees_rus', response.fees_rus);
            setData(configCCDNLite, 'button_rate_mpaa', response.rate_mpaa);
            setData(configCCDNLite, 'button_trivia', response.trivia);
            setData(configCCDNLite, 'button_composer', response.composer);

            uploadField(configCCDNLite, 'button_download_poster', response.poster);

        }).fail(function (response) {
            DLEalert('Что-то пошло не так. Код ошибки: ' + response.status + '<br> Сообщение: ' + response.responseText, "Сообщение об ошибке!");
        });
    })
});


function formatRepo(repo) {
    if (repo.loading) {
        return repo.text;
    }

    var $container = $(
        "<div class='select2-result-repository clearfix'>" +
        "<div class='select2-result-repository__poster'><img src='" + repo.poster + "' /></div>" +
        "<div class='select2-result-repository__meta'>" +
        "<div class='select2-result-repository__title'></div>" +
        "<div class='select2-result-repository__statistics'>" +
        "<div class='select2-result-repository__origin_name'></div>" +
        "<div class='select2-result-repository__year'><b>Год</b>: </div>" +
        "<div class='select2-result-repository__kp'><b>Kinopoisk</b>: </div>" +
        "<div class='select2-result-repository__imdb'><b>IMDB</b>: </div>" +
        "</div>" +
        "</div>" +
        "</div>"
    );

    $container.find(".select2-result-repository__title").text(repo.name);
    $container.find(".select2-result-repository__origin_name").append(repo.origin_name);
    $container.find(".select2-result-repository__year").append(repo.year);
    $container.find(".select2-result-repository__kp").append(repo.kinopoisk);
    $container.find(".select2-result-repository__imdb").append(repo.imdb);

    return $container;
}
