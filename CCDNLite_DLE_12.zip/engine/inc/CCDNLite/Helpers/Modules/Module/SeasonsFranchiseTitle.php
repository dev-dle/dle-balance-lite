<?php

namespace CCDNLite\Helpers\Modules\Module;

use CCDNLite\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDNLite\Helpers\Entities\Config;
use CCDNLite\Helpers\Entities\Post;
use CCDNLite\Helpers\FacadeStatic;

/**
 * Class SeasonsFranchiseTitle
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDNLite\Helpers\Modules\Module
 */
class SeasonsFranchiseTitle extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return SeasonsFranchiseTitle
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title === '1') {
            return $this->_handlerTitle($config, $response, $post);
        }

        return $post->title;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerTitle(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $title = $config->module_title_pattern;

        if (empty($title)) {
            return $post->title;
        }

        if ($config->module_add_episode === '1') {
            if ($config->module_add_episode_inc_one) {
                $episode++;
            }
            $title = $segments->replaceEpisode($title, $episode, (int) $config->module_episode_format);

            $post->setField($config->module_add_episode_custom_filed,
                $segments->createSrtByFormat((int) $config->module_episode_format, $episode)
                .' '.$config->serial_episode_field_suffix
            );
        } else {
            $title = $segments->replaceEpisode($title, '');
        }

        if ($config->module_add_season === '1') {
            if (!empty($config->module_season_format)) {
                $title = $segments->replaceSeason($title, $season, (int) $config->module_season_format);
                $post->setField($config->module_add_season_custom_filed,
                    $segments->createSrtByFormat((int) $config->module_season_format, $season)
                    .' '.$config->serial_season_field_suffix
                );
            } else {
                $title = $segments->replaceSeason($title, $season);
            }
        } else {
            $title = $segments->replaceSeason($title, '');
        }


        $title = $segments->replaceYear($title, $response->getYear());

        $title = $segments->replaceOriginName($title, $response->getNameEng());

        $title = $segments->replaceTitle($title, $response->getName());

        return $title;
    }
}
