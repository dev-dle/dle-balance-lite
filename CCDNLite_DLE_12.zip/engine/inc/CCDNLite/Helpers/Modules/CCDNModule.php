<?php

namespace CCDNLite\Helpers\Modules;

use CCDNLite\Helpers\Cache;
use CCDNLite\Helpers\Http\Response;
use CCDNLite\Helpers\Logger\Log;
use Exception;

class CCDNModule
{

    /**
     * @param  string  $name
     * @param  callable  $f
     * @return mixed
     */
    public static function run($name, callable $f)
    {
        if (!defined('DATALIFEENGINE')) {
            Response::staticAddHeader('HTTP/1.1 403 Forbidden', '')
                ->redirect('../../', true, 403);
            die('Oh, you shouldn`t be here!');
        }

        try {
            return $f($name, new Cache());
        } catch (Exception $e) {
            (new Log())->write($name, $e->getMessage());
            return '';
        }
    }
}
