<?php

namespace CCDNLite\Helpers\Api\Response\Items;

use CCDNLite\Helpers\Api\Response\Field\IframeUrlFieldInterface;
use CCDNLite\Helpers\Api\Response\Field\VoicesFieldInterface;

interface EpisodeItemInterface extends ItemInterface
{

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return VoicesFieldInterface
     */
    public function getVoiceActing();

    /**
     * @return bool
     */
    public function getAds();

}
