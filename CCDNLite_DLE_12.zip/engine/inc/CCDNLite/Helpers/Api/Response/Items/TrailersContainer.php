<?php

namespace CCDNLite\Helpers\Api\Response\Items;

class TrailersContainer extends Item implements TrailersContainerInterface
{
    /**
     * @return TrailerItemInterface
     */
    public function getLast()
    {
        $trailerItem = !$this->isEmpty() ? end($this->data) : [];
        return new Trailer($trailerItem);
    }

    /**
     * @param  int  $number
     * @return TrailerItemInterface
     */
    public function get($number)
    {
        if ($this->isEmpty()) {
            return new Trailer();
        }

        return isset($this->data[$number]) ? new Trailer($this->data[$number]) : new Trailer();
    }
}
