<?php

namespace CCDNLite\Helpers\Api\Response\Items;

use CCDNLite\Helpers\Api\Response\Field\IframeUlrField;

class Trailer extends Item implements TrailerItemInterface
{

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getNumber()
    {
        return $this->getField('number');
    }

    /**
     * @inheritDoc
     */
    public function getSeason()
    {
        return $this->getField('season');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return new IframeUlrField($this->getField('iframe_url'));
    }
}
