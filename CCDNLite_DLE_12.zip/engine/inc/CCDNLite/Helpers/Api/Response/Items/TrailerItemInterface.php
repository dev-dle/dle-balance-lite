<?php

namespace CCDNLite\Helpers\Api\Response\Items;

use CCDNLite\Helpers\Api\Response\Field\IframeUrlFieldInterface;

interface TrailerItemInterface extends ItemInterface
{

    /**
     * @return string
     */
    public function getName();

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return int
     */
    public function getSeason();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();
}
