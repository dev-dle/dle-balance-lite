<?php

namespace CCDNLite\Helpers\Api\Response\Field;


class GenreField extends ArrayField
{


}
