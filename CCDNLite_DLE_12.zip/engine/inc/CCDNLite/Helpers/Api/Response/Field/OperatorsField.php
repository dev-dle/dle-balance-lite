<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class OperatorsField extends ArrayField implements OperatorsFieldInterface
{

}
