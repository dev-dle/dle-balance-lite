<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface PartsFieldInterface extends ArrayFieldInterface
{

}
