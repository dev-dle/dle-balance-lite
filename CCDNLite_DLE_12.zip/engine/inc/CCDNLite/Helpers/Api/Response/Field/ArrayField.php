<?php


namespace CCDNLite\Helpers\Api\Response\Field;


class ArrayField implements ArrayFieldInterface
{
    /**
     * @var array
     */
    protected $data;

    /**
     * Voices constructor.
     * @param  array  $data
     */
    public function __construct($data = [])
    {
        $this->data = $data;
    }

    /**
     * @inheritDoc
     */
    public function getList()
    {
        return $this->data;
    }

    /**
     * @inheritDoc
     */
    public function implode($deliver = ', ')
    {
        return implode($deliver, $this->data);
    }

    /**
     * @inheritDoc
     */
    public function isEmpty()
    {
        return empty($this->data);
    }

    public function has($item, $strict = true)
    {
        return in_array($item, $this->data, $strict);
    }
}
