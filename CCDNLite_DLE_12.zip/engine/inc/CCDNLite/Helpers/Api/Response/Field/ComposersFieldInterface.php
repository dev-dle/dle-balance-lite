<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface ComposersFieldInterface extends ArrayFieldInterface
{

}
