<?php

namespace CCDNLite\Helpers\Api\Response\Field;

interface VoicesFieldInterface extends ArrayFieldInterface
{

    /**
     * @param  array  $items
     * @return $this
     */
    public function removeFromList($items = []);


    /**
     * @param  array  $priority
     * @return string|null
     */
    public function getVoiceActingByPriority($priority = []);

}
