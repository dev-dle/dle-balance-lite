<?php


namespace CCDNLite\Helpers\Api\Response\Field;


interface DesignsFieldInterface extends ArrayFieldInterface
{

}
