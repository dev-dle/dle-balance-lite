<?php

namespace CCDNLite\Helpers\Api\Response;

/**
 * Class ResponseCollection
 *
 * @link https://api{time}.apicollaps.cc/collection?token={token}
 * @package CCDNLite\Helpers\Api\Response
 */
class Collection extends Response implements CollectionInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }
}
