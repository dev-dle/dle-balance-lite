<?php

namespace CCDNLite\Helpers;

class Arr
{

    /**
     * @param  array  $array
     * @param  string  $key
     * @param  bool  $strict
     * @return array
     */
    public static function unique($array, $key, $strict = true)
    {
        $temp_array = [];
        $key_array = [];

        foreach ($array as $val) {
            if (!in_array($val[$key], $key_array, $strict)) {
                $key_array[] = $val[$key];
                $temp_array[] = $val;
            }
        }
        unset($key_array);
        return $temp_array;
    }
}
