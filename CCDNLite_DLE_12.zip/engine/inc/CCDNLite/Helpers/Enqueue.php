<?php

namespace CCDNLite\Helpers;

/**
 * Class Enqueue
 * @method static string staticAssets($assetFile = '')
 *
 * @package CCDNLite\Helpers
 */
class Enqueue extends FacadeStatic
{

    /**
     * @return Enqueue
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * Return url to asset file
     *
     * @param  string  $assetFile
     *
     * @return string
     */
    public function assets($assetFile)
    {
        $assetFile = trim($assetFile,'/');
        return Settings::ASSETS_URL.$assetFile;
    }

}
