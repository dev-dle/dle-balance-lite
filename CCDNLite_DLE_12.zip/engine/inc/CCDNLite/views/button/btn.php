<?php

/**
 * @var Config $settings
 */

use CCDNLite\Helpers\Enqueue;
use CCDNLite\Helpers\Entities\Config;
use CCDNLite\Helpers\GA;
use CCDNLite\Helpers\Http\Url;
use CCDNLite\Helpers\Settings;

global $config;

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel.lite.button', Url::staticGetUri(), Url::staticGetDomain());
global $member_id, $news_id, $dle_login_hash;
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
<link href="<?php echo Enqueue::staticAssets('css/button.css') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"
      rel="stylesheet"
      type="text/css">
<div class="form-group">
    <label class="control-label col-md-2"><b>CCDNLite:</b></label>
    <div class="col-md-2">
        <button type="button"
                data-update-url="<?php echo Url::staticTo('btn-get-franchise-details') ?>"
                class="btn btn-success ccdn-lite-update-embed-js">
            Найти эмбед
        </button>
    </div>
    <div class="col-md-4">
        <label class="control-label" for="ccdn-lite-search">
            Поиск по базе Collaps
        </label>
        <select id="ccdn-lite-search"
                data-url="<?php echo Url::staticTo('btn-search') ?>"
                data-update-url="<?php echo Url::staticTo('btn-get-franchise-details') ?>"
        ></select>
    </div>
    <div class="col-md-offset-4">
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script type="text/javascript">
    const configCCDNLite = <?php echo json_encode($settings)?>;
    const memberCCDNLite = <?php echo json_encode($member_id)?>;
    const newsIdCCDNLite = <?php echo $news_id?>;
    const CCDNLiteDLEConfig = <?php echo json_encode($config)?>;
    const loginHashIdCCDNLite = '<?php echo $dle_login_hash?>';
    const btnConditionTextCCDNLite = {
        search: '<i class="spinner-border spinner-border-sm"></i> Поиск...',
        normal: 'Найти эмбед'
    };
</script>
<script type="text/javascript"
        src="<?php echo Enqueue::staticAssets('js/button.js') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"></script>
<script type="text/javascript"
        src="<?php echo Enqueue::staticAssets('js/search-select.js') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"></script>
