<?php
/**
 * @var array $customFields
 * @var VoiceActionInterface[] $voices
 * @var array $videoVoicePriority
 * @var array $videoVoicesDisable
 * @var Config $config
 * @var string $categoriesList
 */

use CCDNLite\Helpers\Api\Response\VoiceActionInterface;
use CCDNLite\Helpers\Enqueue;
use CCDNLite\Helpers\Entities\Config;
use CCDNLite\Helpers\GA;
use CCDNLite\Helpers\HTML;
use CCDNLite\Helpers\Http\Url;
use CCDNLite\Helpers\MenuBuilder;
use CCDNLite\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки',
    ]
);

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel.lite', Url::staticGetAction(), Url::staticGetDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo Enqueue::staticAssets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <form class="needs-validation" action="<?php echo Url::staticTo('settings-save-config') ?>"
                          method="POST">
                        <h3>Основные настройки</h3>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="api_key">
                                    API ключ
                                    <?php if ((int) $config->status_api_key): ?>
                                        <span class="badge badge-success">Активный</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Неактивный</span>
                                    <?php endif; ?>
                                </label>
                                <input type="text" class="form-control" id="api_key"
                                       name="settings[api_key]" placeholder=""
                                       value="<?php echo $config->api_key ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="embed_field">Доп. поле для вставки эмбеда</label>
                                <select class="form-control" name="settings[embed_field]" id="embed_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->embed_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="kinopoisk_id_field">ID видео на kinopoisk.ru из поля</label>
                                <select class="form-control" name="settings[kinopoisk_id_field]"
                                        id="kinopoisk_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->kinopoisk_id_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="imdb_id_field">ID видео на ImDb из поля</label>
                                <select class="form-control" name="settings[imdb_id_field]" id="imdb_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->imdb_id_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="world_art_id_field">ID видео на World Art из поля</label>
                                <select class="form-control" name="settings[world_art_id_field]"
                                        id="world_art_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->world_art_id_field,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <h3>Настройки массового обновления</h3>

                        <div class="row mt-15 mb-20">
                            <div class="form-group col-md-6">
                                <label for="video_voice_priority">
                                    Приоритет озвучек для вставки первой озвучки в доп. поле
                                    <?php echo HTML::helpPopover('По указанному приоритету озвучки будут проставлена в полепервой
                                       озвучки, если приоритет не указан или совпадений не найдено будет проставлена
                                       та озвучка, которая идет первой в базе балансера!') ?>
                                </label>

                                <select multiple id="video_voice_priority" class="form-control"
                                        name="settings[video_voice_priority][]">
                                    <?php foreach ($voices as $voice) : ?>
                                        <?php if (in_array($voice->getName(), $videoVoicePriority,
                                            true)) {
                                            continue;
                                        } ?>
                                        <option value="<?php echo $voice->getName() ?>"><?php echo $voice->getName() ?></option>
                                    <?php endforeach; ?>
                                    <?php foreach ($videoVoicePriority as $value) : ?>
                                        <option selected value="<?php echo $value ?>"><?php echo $value ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="video_first_voice_field">Доп. поле для вставки первой озвучки</label>
                                <select class="form-control" name="settings[video_first_voice_field]"
                                        id="video_first_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_first_voice_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="video_voices_disabled">
                                    Заблокированные озвучки в плеере
                                </label>
                                <select multiple id="video_voices_disabled" class="form-control"
                                        name="settings[video_voices_disabled][]">
                                    <?php foreach ($voices as $voice) : ?>
                                        <?php if (in_array($voice->getName(), $videoVoicesDisable,
                                            true)) {
                                            continue;
                                        } ?>
                                        <option value="<?php echo $voice->getName() ?>"><?php echo $voice->getName() ?></option>
                                    <?php endforeach; ?>
                                    <?php foreach ($videoVoicesDisable as $value) : ?>
                                        <option selected value="<?php echo $value ?>"><?php echo $value ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="video_voice_field">Доп. поле для вставки всех доступных озвучек</label>
                                <select class="form-control" name="settings[video_voice_field]" id="video_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_voice_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="video_quality_field">Доп. поле для вставки качества видео</label>
                                <select class="form-control" name="settings[video_quality_field]"
                                        id="video_quality_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_quality_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="post_status_field">Доп. поле для статуса новости. Значение по умолчанию
                                    должно
                                    быть - Включено!
                                    <?php echo HTML::helpPopover('Это поле типа ""Переключатель Да или Нет".
                                       Которое будет отвечать за то нужно ли обновлять эту новость или нет.') ?>
                                </label>
                                <select class="form-control" name="settings[post_status_field]" id="post_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->post_status_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-20 mb-20">
                            <div class="form-group col-md-6">
                                <label for="serial_season_field">Доп. поле для выбора сезона
                                    <?php echo HTML::helpPopover('Если заполнено - будет проставлена ссылка на указанный сезон сериала') ?>
                                </label>
                                <select class="form-control" name="settings[serial_season_field]"
                                        id="serial_season_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_season_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field">Доп. поле для выбора серии
                                    <?php echo HTML::helpPopover('Если заполнено - будет проставлена ссылка на указанную серию сериала') ?>
                                </label>
                                <select class="form-control" name="settings[serial_episode_field]"
                                        id="serial_episode_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_episode_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_season_field_suffix">
                                    Текст для добавления в поле с сезонами
                                </label>
                                <input type="text" class="form-control" id="serial_season_field_suffix"
                                       name="settings[serial_season_field_suffix]" placeholder=""
                                       value="<?php echo $config->serial_season_field_suffix ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field_suffix">
                                    Текст для добавления в поле с серией
                                </label>
                                <input type="text" class="form-control" id="serial_episode_field_suffix"
                                       name="settings[serial_episode_field_suffix]" placeholder=""
                                       value="<?php echo $config->serial_episode_field_suffix ?>">
                            </div>
                        </div>
                        <div class="row mt-20 mb-20 pt-20">
                            <div class="form-group col-md-6">
                                <label for="episode_count_field">Доп. поле для вставки количества серий
                                    <?php echo HTML::helpPopover('Это поле нужно заполнить, если вы хотите обновлять дату новости при выходе новых серий сериалов.
                                       Оно нужно только для модуля!') ?>
                                </label>
                                <select class="form-control" name="settings[episode_count_field]"
                                        id="episode_count_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->episode_count_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="collaps_franchise_ads_status_field">Доп. поле для вставки статуса рекламы
                                    <?php echo HTML::helpPopover('Это поле будет полезным для того чтобы скрывать плеер, в поле буде писатся +, если в франшизе присутствует вшитая реклама азарта и ничего если рекламы нет') ?>
                                </label>
                                <select class="form-control" name="settings[collaps_franchise_ads_status_field]"
                                        id="collaps_franchise_ads_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->collaps_franchise_ads_status_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <div class="checkbox">
                                    <label class="mr-20" for="set_season_episode_to_embed">
                                        Добавлять сезон серию в ссылку на эмбед
                                    </label>
                                    <input type="hidden" value="0" name="settings[set_season_episode_to_embed]">
                                    <input id="set_season_episode_to_embed" type="checkbox"
                                           name="settings[set_season_episode_to_embed]"
                                           value="1"
                                        <?php echo HTML::checked($config->set_season_episode_to_embed, 1) ?>>
                                </div>
                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <div class="checkbox">
                                    <label class="mr-20" for="content_ads_filter">Фильтровать контент с рекламой
                                        <?php echo HTML::helpPopover('Все материалы с вшитой рекламой будут игнорироваться модулем, 
                                        на такие материалы не будут проставляться ссылки, также не будет работать автоподнятие, 
                                        если новая серия имееет вшитую рекламу!') ?>
                                    </label>
                                    <input type="hidden" value="0" name="settings[content_ads_filter]">
                                    <input id="content_ads_filter" type="checkbox"
                                           name="settings[content_ads_filter]"
                                           value="1"
                                        <?php echo HTML::checked($config->content_ads_filter, 1) ?>>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-12">
                            <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="<?php echo Enqueue::staticAssets('js/main.js') ?>"></script>
    <script>
        $(document).ready(function () {
            $('select').each(function (index, element) {
                if (element.id !== 'video_voice_priority' && element.id !== 'video_voices_disabled') {
                    $(element).select2({
                        placeholder: 'Выбрать...',
                        width: '100%',
                        allowClear: true,
                        multiple: false,
                    });
                }
            });

            var videoVoicePrioritySelect = $('#video_voice_priority');
            var videoVoicesDisableSelect = $('#video_voices_disabled');
            const selectCong = {
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
                multiple: true,
            };

            videoVoicesDisableSelect.select2(selectCong);

            videoVoicePrioritySelect.select2(selectCong);
            videoVoicePrioritySelect.on("select2:select", function (evt) {
                var element = evt.params.data.element;
                var $element = $(element);
                $element.detach();
                $(this).append($element);
                $(this).trigger("change");
            });

            videoVoicePrioritySelect.on("select2:unselect", function (evt) {
                var element = evt.params.data.element;
                select.append(element);
            });
        })
    </script>
<?php
echofooter();
