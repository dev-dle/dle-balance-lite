<?php

namespace CCDNLite\Controllers;

use CCDNLite\Helpers\Controller;
use CCDNLite\Helpers\DB\SettingsSave;
use CCDNLite\Helpers\Exception\CCDNException;
use CCDNLite\Helpers\Http\Request;
use CCDNLite\Helpers\Http\Response;
use CCDNLite\Helpers\Http\Url;
use CCDNLite\Helpers\Modules\Module\PatterParser;
use CCDNLite\Helpers\Settings;
use CCDNLite\Helpers\XFields;

class ModuleController extends Controller
{

    protected $viewsFolder = 'module';

    /**
     * @return string
     */
    public function main()
    {
        $customFields = XFields::staticLoad();

        $customFieldsTmp = [];

        foreach ($customFields as $field) {
            $customFieldsTmp[$field['key']] = $field['name'];
        }

        return Response::staticMake($this->render('module', [
            'configCCDN' => Settings::staticAll(),
            'customFields' => $customFieldsTmp,
            'segments' => new PatterParser(),
        ]));
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->module();
        Response::staticRedirect(Url::staticTo('module'));
    }
}
