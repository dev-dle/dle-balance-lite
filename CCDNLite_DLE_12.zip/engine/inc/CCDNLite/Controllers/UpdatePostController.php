<?php

namespace CCDNLite\Controllers;

use CCDNLite\Helpers\Api\ApiHandler;
use CCDNLite\Helpers\Api\Response\Field\IframeUlrField;
use CCDNLite\Helpers\DB\Model;
use CCDNLite\Helpers\DB\PostMapper;
use CCDNLite\Helpers\Exception\CCDNException;
use CCDNLite\Helpers\Http\Request;
use CCDNLite\Helpers\Http\Response;
use CCDNLite\Helpers\SearchResolver;
use CCDNLite\Helpers\Settings;

class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {
        if (!is_numeric($request->get('chunk'))) {
            throw new CCDNException('Chunk not number');
        }

        $config = Settings::staticAll();
        $postMapper = new PostMapper();
        $searchResolver = new SearchResolver();


        $posts = $postMapper->selectPosts($request->get('chunk'));
        $responses = $searchResolver->multiHandler(new ApiHandler(), $posts);
        foreach ($responses as $postId => $response) {

            $post = $posts[$postId];
            $season = $seasonsNumber = '';
            $episode = $episodesNumber = '';
            $iframeUrl = $response->getIframeUrl()->get();
            $postSeason = $post->getNumberFromField($config->serial_season_field);
            $postEpisode = $post->getNumberFromField($config->serial_episode_field);

            if ($response->getType()->isSeasons()) {

                if ($postEpisode === null || $postSeason === null) {
                    $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
                    $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

                    $season = $seasonsNumber.' '.$config->serial_season_field_suffix;
                    $episode = $episodesNumber.' '.$config->serial_episode_field_suffix;

                    $iframeUrl = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getIframeUrl()->get();
                } else {
                    $iframeUrl = $response->getSeasons()->get($postSeason)->getEpisodes()->getLast()->getIframeUrl()->get();
                }

                if ($config->set_season_episode_to_embed === '0') {
                    $iframeUrl = $response->getIframeUrl()->get();
                }
            }

            $videoVoicesDisabled = $config->getJsonDecode('video_voices_disabled');

            $voiceActingStr = $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implode();

            $firstVoice = $response->getVoicesActing()
                ->removeFromList($videoVoicesDisabled)
                ->getVoiceActingByPriority($config->getJsonDecode('video_voice_priority'));

            $iframeUrlHandler = new IframeUlrField($iframeUrl);

            $iframeUrl = $iframeUrlHandler->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

            $post->setField($config->collaps_franchise_ads_status_field, (int) $response->getAds());
            $post->setField($config->embed_field, $iframeUrl);
            $post->setField($config->kinopoisk_id_field, $response->getKinopoiskId());
            $post->setField($config->imdb_id_field, $response->getImdbId());
            $post->setField($config->world_art_id_field, $response->getWorldArtId());
            $post->setField($config->serial_season_field, $season);
            $post->setField($config->serial_episode_field, $episode);
            $post->setField($config->video_voice_field, $voiceActingStr);
            $post->setField($config->video_first_voice_field, $firstVoice);
            $post->setField($config->video_quality_field, $response->getQuality());
            $post->setField($config->episode_count_field, $response->getSeasons()->getAllEpisodesCount());


            if ($config->content_ads_filter === '1' && $response->getAds()) {
                $post->deleteField($config->embed_field);
            }

            $post->updatePost();
        }

        return Response::staticJson([
            'status' => 'Ok'
        ]);
    }

    /**
     * @return string
     *
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();
        $count = $model->select("SELECT COUNT(`id`) as count FROM  {$model->getPrefix()}_post");
        $totalPostCount = (int) $count['count'];
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);

        return Response::staticJson([
            'chunksCount' => $chunksCount,
        ]);

    }
}
